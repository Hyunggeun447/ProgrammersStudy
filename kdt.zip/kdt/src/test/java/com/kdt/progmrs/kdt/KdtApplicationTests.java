package com.kdt.progmrs.kdt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KdtApplicationTests {

	@Test
	void contextLoads() {
	}

}
